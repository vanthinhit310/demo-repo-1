<footer class="main-footer">
    <?php echo $__env->yieldContent('footer'); ?>
</footer><?php /**PATH /home/dev/codes/demo/resources/views/vendor/adminlte/partials/footer/footer.blade.php ENDPATH**/ ?>